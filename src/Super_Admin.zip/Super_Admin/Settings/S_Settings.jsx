const S_Settings = () => <h1>Admin Settings</h1>;
export default S_Settings;
