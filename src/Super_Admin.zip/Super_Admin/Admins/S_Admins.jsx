const S_Admins = () => <h1>Super Admins Management</h1>;
export default S_Admins;
