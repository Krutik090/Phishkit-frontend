const S_Log = () => <h1>System Logs</h1>;
export default S_Log;
