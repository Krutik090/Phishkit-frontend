const S_project = () => <h1>Project Management</h1>;
export default S_project;