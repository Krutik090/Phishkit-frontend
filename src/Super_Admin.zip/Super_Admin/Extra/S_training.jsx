const S_training = () => <h1>Training</h1>;
export default S_training;