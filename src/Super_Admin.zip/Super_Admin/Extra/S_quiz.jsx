const S_quiz = () => <h1>Quiz</h1>;
export default S_quiz;