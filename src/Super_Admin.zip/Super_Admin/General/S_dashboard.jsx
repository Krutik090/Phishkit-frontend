const S_dashboard = () => <h1>General  Dashboard</h1>;
export default S_dashboard;
