const S_templates = () => <h1>Templates</h1>;
export default S_templates;
