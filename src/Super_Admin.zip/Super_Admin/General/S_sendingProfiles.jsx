const S_sendingProfiles = () => <h1>Sending Profiles</h1>;
export default S_sendingProfiles;
