const S_landingPage = () => <h1>Landing Page</h1>;
export default S_landingPage;
