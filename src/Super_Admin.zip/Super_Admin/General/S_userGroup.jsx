const S_userGroup = () => <h1>User Group</h1>;
export default S_userGroup;
