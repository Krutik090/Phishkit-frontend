const S_campaign = () => <h1>Campaign</h1>;
export default S_campaign;
