const S_Dashboard = () => <h1>Super Admin Dashboard</h1>;
export default S_Dashboard;
